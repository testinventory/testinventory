<?php
namespace Inventory\Check\Controller\Index;


class GetProductDetail extends \Magento\Framework\App\Action\Action 
{
      protected $productRepository; 
      protected $_stockItemRepository;
      protected $resultJsonFactory;

      
      public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        array $data = []
      ) {
          parent::__construct($context);
          $this->productRepository = $productRepository;
          $this->request = $context->getRequest();
          $this->_stockItemRepository = $stockItemRepository;
          $this->resultJsonFactory = $resultJsonFactory;
      }
      public function execute()
      { 
          $data=array();
          $item=array();
          $Id = $this->request->getParam('id');
          $configurable_product=$this->productRepository->getById($Id);
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
          $store = $objectManager->get('Magento\Store\Model\StoreManagerInterface')->getStore();
          $imageUrl = $store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'catalog/product' . $configurable_product->getImage();
          $product_desc=$configurable_product->getDescription();
          
          $product_url=$configurable_product->getUrlModel()->getUrl($configurable_product);

          $configProduct = $objectManager->create('Magento\Catalog\Model\Product')->load($Id);
          
          $_children = $configProduct->getTypeInstance()->getUsedProducts($configProduct);
          
          //$colorAttributeId = $configurable_product->getResource()->getAttribute('color')->getId(); // Get Color Attribute Id

          //$sizeAttributeId = $configurable_product->getResource()->getAttribute('size')->getId(); // Get Size Attribute Id


          //$configurableAttrs = $configurable_product->getTypeInstance()->getConfigurableAttributesAsArray($configurable_product); 
          // Get Used Attributes with its values

          // if(isset($configurableAttrs[$colorAttributeId])){
          //     $data['color']=$configurableAttrs[$colorAttributeId]['values'];
          // }
          
          // if(isset($configurableAttrs[$sizeAttributeId])){
          //     $data['size']=$configurableAttrs[$sizeAttributeId]['values'];
          // }
         
          
            
          
          foreach ($_children as $key => $child)
          { 
              //$productStockObj= $this->_stockItemRepository->get($child->getID());
              $productStockObj = $objectManager->get('Magento\CatalogInventory\Api\StockRegistryInterface')->getStockItem($child->getID());
              $subitem=array();
              $subitem['color']=$child->getColor();
              $subitem['size']=$child->getSize();
              $subitem['price']=$child->getPrice();
              $stockInfo=$productStockObj->getData();;
              $subitem['qty']=$stockInfo['qty'];
              $subitem['product_id']=$child->getID();
              array_push($item,$subitem);              
          }

          $result['0'] =  $product_url;
          // $result['1'] =  $data['color'];
          // $result['2'] =  $data['size'];
          $result['1'] =  $item;
          $result['2'] =  $imageUrl;
          $result['3'] =  $product_desc;
          $result['4'] =  $Id;

          $resultJson = $this->resultJsonFactory->create();
          return $resultJson->setData($result);

          // echo json_encode(array(
          //               $product_url,
          //               $data['color'],
          //               $data['size'],
          //               $item,
          //               $imageUrl,
          //               $product_desc,
          //               $Id
          //           ));

         

      }
    
      

}