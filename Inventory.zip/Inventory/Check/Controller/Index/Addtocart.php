<?php


namespace Inventory\Check\Controller\Index;

class Addtocart extends \Magento\Framework\App\Action\Action 
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;
    protected $productRepository;
    /**
     * Addpack constructor.
     * 
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Quote\Api\CartRepositoryInterface $cartRepository
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     */
 
    public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Quote\Api\CartRepositoryInterface $cartRepository,
    \Magento\Catalog\Model\ProductFactory $productFactory,
    \Magento\Catalog\Model\ProductRepository $productRepository
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->checkoutSession = $checkoutSession;
        $this->cartRepository = $cartRepository;
        $this->productFactory = $productFactory;
        $this->productRepository = $productRepository;
        parent::__construct($context);
    }


    public function execute()
    {
        //$resultRedirect = $this->resultRedirectFactory->create();
        try {
            $postedData = $this->getRequest()->getPostValue();
            $configurable_product=$this->productRepository->getById($postedData['parent']['id'] );
            $quote = $this->checkoutSession->getQuote();
            $product='';
            foreach ($postedData['parent']['prod_array'] as $productId => $qty) {

                if($qty>0){
                    $params = array();
                    $params['qty'] = $qty;//product quantity
                    $product = $this->productFactory->create()->load($productId);
                    if ($product->getId()) {
                        $quote->addProduct(
                            $product,
                            intval($qty)
                        );
                    }
                }
            }

            $this->cartRepository->save($quote);
            $this->checkoutSession->replaceQuote($quote)->unsLastRealOrderId();
            $message = __(
                'You added %1 to your shopping cart.',
                $configurable_product->getName()
            );
            $this->messageManager->addSuccessMessage($message);
            //$this->messageManager->addSuccess(__('Add to cart successfully.'));
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addException(
                $e,
                __('%1', $e->getMessage())
            );
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('error.'));
        }
        /*cart page*/
        $this->getResponse()->setRedirect('/checkout/cart');
        //return $resultRedirect->setPath('customer/account/');
    }

}