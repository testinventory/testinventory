<?php
namespace Inventory\Check\Block;
class Index extends \Magento\Framework\View\Element\Template
{
	protected $_productCollectionFactory;

     public function __construct(
        \Magento\Backend\Block\Template\Context $context,        
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,        
        array $data = []
    )
     {
        $this->_productCollectionFactory = $productCollectionFactory;    
        parent::__construct($context, $data);
     }

    public function getAction()
    {
      return $this->getUrl('newsletter/manage/save');
    }

    public function getProductCollection()
    {
       $collection = $this->_productCollectionFactory->create();
       $collection->addAttributeToSelect('*')->addAttributeToFilter('type_id', 'configurable');
       //$collection->setPageSize(3); // fetching only 3 products
       return $collection;
    }


}




